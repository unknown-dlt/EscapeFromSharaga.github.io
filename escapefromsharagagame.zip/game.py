import pygame
from PIL import Image


pygame.init()

pygame.mixer.init()

WIDTH, HEIGHT = 1500, 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('escape from sharaga')


pygame.mixer.music.load('game_beat_sosal.mp3')
pygame.mixer.music.play(loops=-1, start=0.0)

player_x, player_y = 2450, 2200
player_width, player_height = 120, 100
player_speed = 8

camera = pygame.Rect(0, 0, WIDTH, HEIGHT)

background_image = pygame.image.load('images/map.png')
background_image = pygame.transform.scale(background_image, (5000, 5000))

player_image = pygame.image.load('images/player1.png')
player_image = pygame.transform.scale(player_image, (player_width, player_height))

water_cooler_image = pygame.image.load('images/water.png')
water_cooler_image = pygame.transform.scale(water_cooler_image, (250, 200))

npc_image = pygame.image.load('images/guard.png')
npc_image = pygame.transform.scale(npc_image, (120, 100))

npc2_image = pygame.image.load('images/kurator.png')
npc2_image = pygame.transform.scale(npc2_image, (120, 100))

npc3_image = pygame.image.load('images/director.png')
npc3_image = pygame.transform.scale(npc3_image, (120, 100))

npc4_image = pygame.image.load('images/guard.png')
npc4_image = pygame.transform.scale(npc4_image, (120, 100))

dialog_messages_cooler = [
    "Как же я устал. Всегда одно и то же. Напиться воды, а потом снова в кабинет, где нас мучают питонами сишарпом аштимелем.",
    "Зачем я вообще здесь? Почему я должен сидеть здесь, когда жизнь ждет меня за дверью?",
    "Может, стоит просто прогулять пару? Или уйти совсем.",
    "А почему нет? Я не хочу тратить время на что-то, что не приносит радости. Так все я ухожу."
]

dialog_messages_npc = [
    "Охранник: Эй, парень! Куда это ты так рано спешишь пары еще не закончились ",
    "Игрок: Здравствуйте. Да просто выхожу подышать свежим воздухом. ",
    "Охранник: Свежий воздух, говоришь? Не слишком ли ты много времени проводишь на улице? ",
    "Игрок: Иногда нужно немного отдохнуть от учебы, знаете ли.",
    "Охранник: Понимаю. Но если ты хочешь прогулять пары я должен дать тебе одно задание ",
    "Игрок: Какое задание?",
    "Охранник: Мне нужно, чтобы ты нашел куратора своей группы. И она должна будет тебя проводить и подписать бумагу потому что без её подписи я не могу тебя выпустить.",
    "Игрок: Зачем мне это делать? Я взрослый пацан я сам могу выйти из шараги ",
    "Охранник: Я понимаю, но таковы правила колледжа. А ты как раз их хочешь нарушить. Если не сделаешь это сейчас, могут возникнуть проблемы с твоим посещением . ",
    "Игрок: Ладно, где я могу ее найти?",
    "Охранник: Обычно она в своем кабинете на первом этаже в 101 но может быть на встрече . Попробуй сначала заглянуть туда. Если не найдешь, то я не смогу тебя отпустить домой",
    "Игрок: Да, конечно. У меня ведь есть много времени на поиски моего куратора.",
    "Охранник: Не будь таким пессимистом. Это может быть хорошей возможностью пообщаться с ней. Может, она сможет тебя переубедить остаться на пары.",
    "Игрок: Или просто скажет мне, что я лентяй который не хочет учиться ",
    "Охранник: Возможно. Но кто знает? Может, она наоборот поможет тебе чтобы ты ушел из колледжа",
    "Игрок: Ладно, я попробую его найти. Если не получится, вернусь к вам. Спасибо за совет. Надеюсь, я смогу быстро справиться с этим заданием.",
]

dialog_messages_npc2 = [
    "Здравствуйте, Марина Владимировна! У меня к вам вопрос… Можно ли как-то пропустить пары сегодня? ",
    "Марина: Привет, Игрок! Прогулять пары? Что случилось?",
    "Игрок: Да просто у меня нет настроения, и я чувствую, что не смогу сосредоточиться. ",
    "Марина: Понимаю, но это не лучший способ справляться с таким настроением. Может ты останешься?",
    "Игрок: Не знаю… но я очень хочу уйти",
    "Марина: Знаешь, у меня есть для тебя важное задание, которое может помочь тебе уйти из колледжа .",
    "Игрок: Какое задание?",
    "Марина: Меня напрягли с документами и ты должен поговорить с директрисой  колледжа. Ей нужна помощь, она хочет как то улучшить колледж но не знает как, и я думаю, что твое мнение было бы очень ценным. И если ты ей поможешь то думаю что она разрешит тебе уйти.",
    "Игрок: Почему именно я? Я не эксперт в этих вопросах.",
    "Марина: Именно поэтому это важно. Ты — студент, и твой взгляд со стороны может помочь нам понять, что действительно нужно. ",
    "Игрок: Ладно, но где мне ее найти?",
    "Марина: Обычно она в своем кабинете в 102, но иногда уходит на встречи. Если ее нет, тогда я ничем не смогу тебе помочь",
    "Игрок: Хорошо, а о чем конкретно мне с ней говорить?",
    "Марина: Я подготовила несколько вопросов, которые ты можешь обсудить с ней. Например, как он видит развитие колледжа и какие изменения планируются в следующем семестре. Это отличная возможность для тебя высказать свои мысли и попросить уйти.",
    "Игрок: Я не уверен, что у меня получиться уйти",
    "Марина: Не переживай! Просто подумай о том, что тебе нравится или не нравится в учебе. Возможно, у тебя есть идеи по улучшению учебного процесса или предложению новых курсов. ",
    "Игрок: Ладно, я попробую. Но если она будет занятым и не захочет разговаривать…",
    "Марина: Не бойся! Директор всегда открыт для студентов. Если она будет занята,просто запишись на встречу. Это нормально.",
    "Игрок: Хорошо, я постараюсь. А что если она спросит меня о моих прогулах?",
    "Марина: Не переживай об этом! Просто будь честен и открыто говори о своих впечатлениях от учебы. Это поможет ей лучше понять студентов.",
    "Игрок: Ладно, я сделаю это. Надеюсь, у меня получится.",
    "Марина:  Уверена, что получится! И помни: это не только твоя задача, но и шанс для тебя уйти из колледжа. ",
    "Игрок: Спасибо за поддержку, Марина Владимировна. Я постараюсь сделать все как можно лучше.",
    "Марина: И не забудь сообщить мне о том уходишь ты или нет!",
    "Игрок: Обязательно! Спасибо еще раз.",

]

dialog_messages_npc3 = [
    "Игрок: Здравствуйте, Директор. Спасибо, что нашли время для встречи.",
    "Директор: Здравствуй, Игрок! Я всегда рад поговорить со студентами. Что тебя привело ко мне?",
    "Игрок: Я хотел обсудить некоторые идеи по поводу дизайна нашего колледжа. Я заметил, что некоторые аспекты могут быть улучшены.",
    "Директор: Интересно! Какие именно идеи у тебя есть?",
    "Игрок: Ну, во-первых, я думаю, что нам стоит обратить внимание на общие пространства. Например, в холле можно добавить больше мест для отдыха — удобные диваны или кресла, где студенты могли бы работать или просто общаться.",
    "Директор: Это хорошая идея. Комфортные зоны могут способствовать общению и сотрудничеству между студентами.",
    "Игрок: Да, и еще я заметил, что некоторые классы выглядят довольно устаревшими. Может быть, стоит обновить мебель и добавить современные технологии? Это сделает занятия более интересными.",
    "Директор: Согласен, новые технологии могут значительно улучшить учебный процесс. Ты прав, это стоит обсудить с преподавателями.",
    "Игрок: Также я подумал о том, чтобы создать несколько зон для групповой работы. Это поможет студентам лучше взаимодействовать и делиться идеями.",
    "Директор: Отличная мысль! Групповая работа действительно важна для развития навыков. Мы могли бы организовать опрос среди студентов, чтобы узнать их мнение.",
    "Игрок: Это было бы здорово! Я уверен, что многие студенты поддержат такие изменения.",
    "Директор: Знаешь, Игрок, я очень ценю твою инициативу и идеи. Это показывает, что ты неравнодушен к своему учебному заведению.",
    "Игрок: Спасибо, Татьяна Вячеславовна. Я просто хочу, чтобы наш колледж стал лучше.",
    "Директор: И это очень похвально! Кстати, Марина упоминала о том, что ты хотел бы уйти с последней пары сегодня. Это связано с твоими идеями?",
    "Игрок: Да, верно. Я надеялся немного поработать над этими предложениями и подготовить их для обсуждения с другими студентами.",
    "Директор: Понимаю. Если ты считаешь, что это действительно важно для общего блага колледжа, я могу отпустить тебя с последней пары. ",
    "Игрок: Спасибо большое! Я постараюсь сделать все возможное.",
    "Директор: Но помни, что важно не забывать об учебе. Если у тебя возникнут проблемы с успеваемостью, мы можем пересмотреть такие решения.",
    "Игрок: Конечно! Я понимаю. Я постараюсь организовать свое время так, чтобы все успевать.",
    "Директор: Отлично! И не забудь мне сообщить о результатах твоей работы над предложениями. Мне будет интересно узнать мнения других студентов.",
    "Игрок: Обязательно! Спасибо еще раз за поддержку и понимание.",
    "Директор: Удачи тебе, Игрок! Надеюсь увидеть твои идеи в действии.",
]

dialog_messages_npc4 = [
    "Игрок: Да, я только что поговорил с Татьяной Вячеславовной она разрешила мне уйти с последней пары.",
    "Охранник: Правда? Это не так уж часто бывает. Ты уверен, что все в порядке?",
    "Игрок: Да, все в порядке! Я обсудил с ней несколько идей по улучшению дизайна колледжа, и она поддержал меня. Я просто хотел поработать над этими предложениями.",
    "Охранник: Ну, это здорово, что ты проявляешь инициативу. Но все равно я должен удостовериться, что у тебя есть разрешение.",
    "Игрок: Конечно, вот сообщение от Татьяны Вячеславовны. Она сказала, что я могу уйти.",
    "Охранник: Хм, вижу. Но все равно, я должен проверить это с ним. Правила есть правила.",
    "Игрок: Понимаю. Я просто надеялся, что смогу уйти пораньше и поработать над идеями.",
    "Охранник: Я понимаю твое желание. Но если я отпущу тебя без подтверждения, могут возникнуть проблемы. Дай мне пару минут, я позвоню директору.",
    "Игрок: Хорошо, спасибо. Я ценю это.",
    "*Охранник достает телефон и набирает номер директора. Игрок ждет, слегка нервничая.*",
    "Охранник: Здравствуйте, Татьяна Вячеславовна. Это Виктор. У нас тут Игрок… Да, он хочет уйти с последней пары. Я просто хочу подтвердить ваше разрешение… Спасибо!",
    "*Кладет трубку и поворачивается к Игроку с улыбкой.*",
    "Охранник: Все в порядке! Татьяна Вячеславовна подтвердила, что ты можешь уходить. Но учти, не забудь вернуться завтра!",
    "Игрок: Спасибо огромное, Виктор! Я обязательно вернусь и расскажу о своих идеях.",
    "Охранник: Хорошо. И не забудь про свои учебные задания! Убедись, что все сделано вовремя.",
    "Игрок: Конечно! Я постараюсь организовать свое время так, чтобы успевать и учиться.",
    "Охранник: Молодец! Вижу, ты на правильном пути. Удачи тебе с твоими предложениями!",
    "Игрок: Спасибо! Надеюсь, они понравятся остальным студентам и преподавателям.",
    "Охранник: И не забывай — если будут еще идеи или предложения, всегда можешь прийти ко мне или к директору!",
    "Игрок: Обязательно! Спасибо еще раз за поддержку!",
    "Охранник: Пока, Игрок..."
]

current_message_index_cooler = 0
current_message_index_npc = 0
current_message_index_npc2 = 0
current_message_index_npc3 = 0
current_message_index_npc4 = 0

in_dialog = False
quest_active = "Попить воды"
dialog_with_cooler_done = False
dialog_with_npc2_done = False
dialog_with_npc3_done = False

npc1_exists = True
npc4_exists = False

def update_game():
    global player_x, player_y, in_dialog, current_message_index_cooler, current_message_index_npc, current_message_index_npc2, current_message_index_npc3, current_message_index_npc4, quest_active, dialog_with_cooler_done, dialog_with_npc2_done, npc1_exists, npc4_exists

    keys = pygame.key.get_pressed()
    if not in_dialog:
        if keys[pygame.K_a]:
            player_x -= player_speed
        if keys[pygame.K_d]:
            player_x += player_speed
        if keys[pygame.K_w]:
            player_y -= player_speed
        if keys[pygame.K_s]:
            player_y += player_speed

        player_x = max(0, min(player_x, 5000 - player_width))
        player_y = max(0, min(player_y, 5000 - player_height))

        camera.center = (player_x + player_width // 2, player_y + player_height // 2)

    cooler_rect = pygame.Rect(2340, 2090, 200, 200)
    if cooler_rect.colliderect(pygame.Rect(player_x, player_y, player_width, player_height)):
        if keys[pygame.K_e] and not in_dialog and quest_active == "Попить воды" and not dialog_with_cooler_done:
            in_dialog = True
            current_message_index_cooler = 0


    if npc1_exists:
        npc_rect = pygame.Rect(1330, 2420, 150, 150)
        if npc_rect.colliderect(pygame.Rect(player_x, player_y, player_width, player_height)):
            if keys[pygame.K_e] and not in_dialog and quest_active == "Отпроситься у охранника":
                in_dialog = True
                current_message_index_npc = 0

    npc2_rect = pygame.Rect(4240, 2860, 150, 120)
    if npc2_rect.colliderect(pygame.Rect(player_x, player_y, player_width, player_height)):
        if keys[pygame.K_e] and not in_dialog and quest_active == "Найти куратора":
            in_dialog = True
            current_message_index_npc2 = 0

    npc3_rect = pygame.Rect(3670, 1850, 150, 120)
    if npc3_rect.colliderect(pygame.Rect(player_x, player_y, player_width, player_height)):
        if keys[pygame.K_e] and not in_dialog and quest_active == "Поговорить с директором":
            in_dialog = True
            current_message_index_npc3 = 0
    player = pygame.Rect(50, 50, 30, 30)
    walls = [
        pygame.Rect(10, 10, 10, 10),
        pygame.Rect(10, 10, 10, 10),
        pygame.Rect(10, 10, 10, 10)
    ]
    pygame.draw.rect(screen, (255, 0, 0), player)
    for wall in walls:
        pygame.draw.rect(screen, (10, 10, 255), wall)

    if npc4_exists:
        npc4_rect = pygame.Rect(1330, 2420, 150, 120)
        if npc4_rect.colliderect(pygame.Rect(player_x, player_y, player_width, player_height)):
            if keys[pygame.K_e] and not in_dialog:
                in_dialog = True
                current_message_index_npc4 = 0

def draw_background():
    screen.blit(background_image, (0 - camera.x, 0 - camera.y))


def draw_dialog():
    global in_dialog, current_message_index_cooler, current_message_index_npc, current_message_index_npc2, current_message_index_npc3, current_message_index_npc4

    if in_dialog:
        pygame.draw.rect(screen, (0, 0, 0), (0, HEIGHT - 150, WIDTH, 150))

        font = pygame.font.Font(None, 36)
        if quest_active == "Отпроситься у охранника":
            text = font.render(dialog_messages_npc[current_message_index_npc], True, (255, 255, 255))
        elif quest_active == "Найти куратора":
            text = font.render(dialog_messages_npc2[current_message_index_npc2], True, (255, 255, 255))
        elif quest_active == "Поговорить с директором":
            text = font.render(dialog_messages_npc3[current_message_index_npc3], True, (255, 255, 255))
        elif quest_active == "Поговорить с охранником":
            text = font.render(dialog_messages_npc4[current_message_index_npc4], True, (255, 255, 255))
        else:
            text = font.render(dialog_messages_cooler[current_message_index_cooler], True, (255, 255, 255))

        screen.blit(text, (50, HEIGHT - 130))

        if (quest_active == "Отпроситься у охранника" and current_message_index_npc < len(dialog_messages_npc) - 1) or \
           (quest_active == "Найти куратора" and current_message_index_npc2 < len(dialog_messages_npc2) - 1) or \
           (quest_active == "Поговорить с директором" and current_message_index_npc3 < len(dialog_messages_npc3) - 1) or \
           (quest_active == "Поговорить с охранником" and current_message_index_npc4 < len(dialog_messages_npc4) - 1) or \
           (quest_active is None and current_message_index_cooler < len(dialog_messages_cooler) - 1):
            continue_text = font.render("Нажмите пробел, чтобы продолжить.", True, (255, 255, 255))
            screen.blit(continue_text, (20, HEIGHT - 30))
        else:
            close_text = font.render("Нажмите пробел, чтобы закрыть диалог.", True, (255, 255, 255))
            screen.blit(close_text, (20, HEIGHT - 30))

def draw_active_quest():
    font = pygame.font.Font(None, 36)
    if quest_active:
        quest_text = font.render(f"Задание: {quest_active}", True, (255, 255, 255))
        screen.blit(quest_text, (WIDTH - quest_text.get_width() - 20, 20))

credits = [
    "Вы сделали это!",
    "После выполненных квестов, вы наконец-то нашли способ покинуть колледж.",
    "Ваше приключение было наполнено неожиданными поворотами, дружбой и смелыми решениями.",
    "Главные разработчики:",
    "Флеш",
    "Длт",
    "Илками",
    "Дизайнеры:",
    "Длт",
    "Программисты:",
    "Флеш",
    "Длт",
    "Сценаристы:",
    "Илками",
    "Длт",
    "Композитор:",
    "Зип",
    "Звукорежиссеры:",
    "Зип",
    "Тестировщики:",
    "длт",
    "флеш"
]

credit_y = HEIGHT
credit_step = 1.5



def draw_credits():
    global credit_y

    pygame.draw.rect(screen, (0, 0, 0), (0, 0, WIDTH, HEIGHT))

    font = pygame.font.Font(None, 36)
    for i, line in enumerate(credits):
        text = font.render(line, True, (255, 255, 255))
        screen.blit(text, (WIDTH // 2 - text.get_width() // 2, credit_y + i * 40))

    credit_y -= credit_step

    if credit_y + len(credits) * 40 <= 0:
        credit_y = HEIGHT

def game_loop():
    global screen, in_dialog, current_message_index_cooler, current_message_index_npc, current_message_index_npc2, current_message_index_npc3, current_message_index_npc4, quest_active, dialog_with_cooler_done, dialog_with_npc2_done, dialog_with_npc3_done, npc1_exists, npc4_exists, credit_y

    clock = pygame.time.Clock()
    running = True

    while running:
        screen.fill((0, 0, 0))

        update_game()

        draw_background()

        screen.blit(water_cooler_image, (2340 - camera.x, 2090 - camera.y))

        if npc1_exists:
            screen.blit(npc_image, (1330 - camera.x, 2420 - camera.y))

        screen.blit(npc2_image, (4240 - camera.x, 2860 - camera.y))

        screen.blit(npc3_image, (3670 - camera.x, 1850 - camera.y))

        if npc4_exists:
            screen.blit(npc4_image, (1330 - camera.x, 2420 - camera.y))

        screen.blit(player_image, (player_x - camera.x, player_y - camera.y))

        draw_active_quest()

        draw_dialog()

        if quest_active is None:
            draw_credits()

        pygame.display.update()
        clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    if in_dialog:
                        if quest_active == "Попить воды":
                            current_message_index_cooler += 1
                            if current_message_index_cooler >= len(dialog_messages_cooler):
                                in_dialog = False
                                quest_active = "Отпроситься у охранника"
                                dialog_with_cooler_done = True

                        elif quest_active == "Отпроситься у охранника":
                            current_message_index_npc += 1
                            if current_message_index_npc >= len(dialog_messages_npc):
                                in_dialog = False
                                quest_active = "Найти куратора"
                        elif quest_active == "Найти куратора":
                            current_message_index_npc2 += 1
                            if current_message_index_npc2 >= len(dialog_messages_npc2):
                                in_dialog = False
                                quest_active = "Поговорить с директором"
                        elif quest_active == "Поговорить с директором":
                            current_message_index_npc3 += 1
                            if current_message_index_npc3 >= len(dialog_messages_npc3):
                                in_dialog = False
                                quest_active = "Поговорить с охранником"
                                npc1_exists = False
                                npc4_exists = True
                        elif quest_active == "Поговорить с охранником":
                            current_message_index_npc4 += 1
                            if current_message_index_npc4 >= len(dialog_messages_npc4):
                                in_dialog = False
                                quest_active = None

    pygame.quit()

game_loop()
