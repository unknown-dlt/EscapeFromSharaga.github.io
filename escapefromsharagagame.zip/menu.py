import pygame
import subprocess
import time

pygame.init()

WIDTH, HEIGHT = 1500, 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Menu - Escape from Sharaga')

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

background_image = pygame.image.load('images/backup.jpg')
background_image = pygame.transform.scale(background_image, (WIDTH, HEIGHT))

font = pygame.font.Font(None, 60)

button_font = pygame.font.Font(None, 50)
play_button = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 - 30, 200, 60)
controls_button = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 + 100, 200, 60)


def draw_button(text, button_rect):
    pygame.draw.rect(screen, WHITE, button_rect)
    text_surface = button_font.render(text, True, BLACK)
    text_rect = text_surface.get_rect(center=button_rect.center)
    screen.blit(text_surface, text_rect)


def loading_screen():
    screen.fill(BLACK)
    loading_text = font.render('Идет загрузка...', True, WHITE)
    screen.blit(loading_text,
                (WIDTH // 2 - loading_text.get_width() // 2, HEIGHT // 2 - loading_text.get_height() // 2))

    pygame.draw.rect(screen, WHITE, (WIDTH // 2 - 200, HEIGHT // 2 + 60, 400, 30))
    pygame.draw.rect(screen, (0, 255, 0), (WIDTH // 2 - 200, HEIGHT // 2 + 60, 400 * 0.75, 30))
    pygame.display.update()
    time.sleep(2)


def menu():
    running = True
    while running:
        screen.blit(background_image, (0, 0))

        draw_button('Играть', play_button)
        draw_button('Управление', controls_button)

        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if play_button.collidepoint(event.pos):

                    loading_screen()
                    subprocess.run(['python', 'game.py'])
                    running = False
                elif controls_button.collidepoint(event.pos):

                    show_controls()

    pygame.quit()


def show_controls():
    running = True
    while running:
        screen.fill(BLACK)
        controls_text = [
            "Управление:",
            "W - Двигаться вверх",
            "S - Двигаться вниз",
            "A - Двигаться влево",
            "D - Двигаться вправо",
            "E - Взаимодействовать",
            "Space - Пропустить/Продолжить диалог"
        ]

        y_offset = 100
        for line in controls_text:
            control_surface = font.render(line, True, WHITE)
            screen.blit(control_surface, (WIDTH // 2 - control_surface.get_width() // 2, y_offset))
            y_offset += 60

        back_text = font.render("Нажмите ESC для возврата", True, WHITE)
        screen.blit(back_text, (WIDTH // 2 - back_text.get_width() // 2, y_offset + 20))

        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False


menu()